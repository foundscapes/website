from foundscapes.site.models import *
from django.contrib import admin

admin.site.register(User)
admin.site.register(Tape)
admin.site.register(Side)
admin.site.register(Track)
admin.site.register(Artwork)